const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// In-memory store of latest sector data
// Shape: { XLK: { price, change1h, change1d, change1m, timestamp }, ... }
let sectorData = {};
let hourlyLog = [];   // last 48 hourly snapshots
let weeklyLog = [];   // last 5 weekly summaries

// ── POST /webhook  ──────────────────────────────────────────────
// TradingView sends here every time an alert fires.
// Expected JSON body (you configure this in the TradingView alert):
// {
//   "ticker":  "XLK",
//   "price":   182.34,
//   "change1h": 0.42,
//   "change1d": 1.12,
//   "change1m": 3.20,
//   "volume":  1234567,
//   "secret":  "YOUR_SECRET_HERE"
// }
app.post('/webhook', (req, res) => {
  const { ticker, price, change1h, change1d, change1m, volume, secret } = req.body;

  // Basic secret check — set WEBHOOK_SECRET in your environment variables
  const expectedSecret = process.env.WEBHOOK_SECRET || 'changeme';
  if (secret !== expectedSecret) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (!ticker) return res.status(400).json({ error: 'ticker required' });

  const ts = new Date().toISOString();
  sectorData[ticker] = { ticker, price, change1h, change1d, change1m, volume, timestamp: ts };

  // Add to hourly log (keep last 480 entries = ~48 hours of 11 sectors each)
  hourlyLog.push({ ...sectorData[ticker] });
  if (hourlyLog.length > 480) hourlyLog = hourlyLog.slice(-480);

  console.log(`[${ts}] Received: ${ticker} @ ${price} (1h: ${change1h}%)`);
  res.json({ ok: true, received: ticker });
});

// ── GET /data  ──────────────────────────────────────────────────
// The tracker widget polls this every 38 seconds
app.get('/data', (req, res) => {
  res.json({
    sectors: Object.values(sectorData),
    hourlyLog,
    weeklyLog,
    lastUpdated: new Date().toISOString()
  });
});

// ── GET /health  ─────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', sectors: Object.keys(sectorData).length }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Sector tracker server running on port ${PORT}`));
